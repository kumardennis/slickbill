import openai


openai.api_key = "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"


#Upload data for training
training_file_name = 'C:/source/ampwise_training_datasets/supplier_dataset.jsonl'

training_response = openai.File.create(
    file=open(training_file_name, "rb"), purpose="fine-tune"
)
training_file_id = training_response["id"]

#Gives training file id
print("Training file id:", training_file_id)