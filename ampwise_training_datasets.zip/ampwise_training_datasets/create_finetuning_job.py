import openai

'Training file id: file-MA8pud1HnFfZkOL1rkP2CRND'

training_file_id = "file-MA8pud1HnFfZkOL1rkP2CRND"

api_key = "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"

openai.api_key = api_key

#Create Fine-Tuning Job
suffix_name = "supplier-bot"

response = openai.FineTuningJob.create(
    api_key=api_key,
    training_file=training_file_id,
    model="gpt-3.5-turbo-0613",
    suffix=suffix_name,
)

job_id = response["id"]

print(response)